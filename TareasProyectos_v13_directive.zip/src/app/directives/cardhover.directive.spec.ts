import { CardhoverDirective } from './cardhover.directive';

describe('CardhoverDirective', () => {
  it('should create an instance', () => {
    const directive = new CardhoverDirective();
    expect(directive).toBeTruthy();
  });
});
