import { Directive,ElementRef,Renderer  } from '@angular/core';

@Directive({
	selector: '[ccCardhover]',
	// selector:".ccCardHover" //Caso class
})
export class CardhoverDirective {

	constructor(private _elementRef: ElementRef,
		private _renderer: Renderer) {
		// _elementRef.nativeElement.style.backgroundColor = "gray";
		_renderer.setElementStyle(_elementRef.nativeElement,'backgroundColor','gray');
	}

}
