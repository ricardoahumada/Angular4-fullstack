import { Component,ViewChild } from '@angular/core';
import {TareasComponent} from './tareas/tareas.component'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  @ViewChild(TareasComponent) tareasViewChild: TareasComponent;

  ngAfterViewInit(){
  	console.log('projectsViewChild is',this.tareasViewChild);
  }

  borrarProyecto(pid){
  	console.log('borrarProyecto:',pid);
  	this.tareasViewChild.borrarTareasDeProyecto(pid);
  }


}
