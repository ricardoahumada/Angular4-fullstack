import { Component, OnInit,Output,EventEmitter } from '@angular/core';

import {Proyecto} from '../modelos/proyecto';


@Component({
  selector: 'app-proyectos',
  templateUrl: './proyectos.component.html',
  styleUrls: ['./proyectos.component.css']
})
export class ProyectosComponent implements OnInit {
  @Output() borrarEvento:EventEmitter=new EventEmitter<number>();

  constructor() { }

  ngOnInit() {
  }

  proyectos:Proyecto[]=[
  	new Proyecto(1,'Web Cliente a'),
  	new Proyecto(2,'App Cliente b')
  ];

  borrarFila(pid){
    console.log('Borrar PID:',pid);
    this.borrarEvento.emit(pid);
  }

}
