export class Proyecto{

    pid:number=0;
    titulo:string='';
    constructor(pid?:number, titulo?:string){
        this.pid=pid;
        this.titulo=titulo;
    }
    
}