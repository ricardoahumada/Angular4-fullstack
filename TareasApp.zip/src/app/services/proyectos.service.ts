import { Injectable } from '@angular/core';
import { Proyecto } from '../modelos/proyecto';

import { HttpClient, HttpResponse } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable()
export class ProyectosService {
  private _proyectosStore: Proyecto[];
  private _apiProyectos: string = 'http://localhost:8080/ProyectosTareas/api/proyectos';
  private _proyectosObs: Observable<Proyecto[]>;

  constructor(private _httpClient: HttpClient) {
  }

  getProyectos(): Proyecto[] {
    return this._proyectosStore;
  }

  getProyectoById(pid: number): Proyecto {
    return this._proyectosStore.find((aP: Proyecto) => (aP.pid == pid));
  }

  getProyectosFromApi(): Observable<Proyecto[]> {

    if (this._proyectosStore) {
      this._proyectosObs = of(this._proyectosStore);
    } else if (this._proyectosObs) {
      //observable ya está en curso
    } else {
      this._proyectosObs = this._httpClient.get<Proyecto[]>(this._apiProyectos)
        .pipe(
          tap(
            data => {
              this._proyectosStore = data;
              localStorage.setItem('proyectos', JSON.stringify(this._proyectosStore));
            },
            error => console.log('error:', error)
          )
        );
    }

    return this._proyectosObs;
  }

  addProyecto(nuevoProj: Proyecto): boolean {
    nuevoProj.pid = (new Date()).getTime();
    this._proyectosStore.push(nuevoProj);
    return true;
  }

  addProyectoToApi(nuevoProj: Proyecto): Observable<number> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this._httpClient.post<number>(this._apiProyectos, nuevoProj, httpOptions)
      .pipe(
        tap(
          data => {
            nuevoProj.pid = data;
            this._proyectosStore.push(nuevoProj);
          },
          error => console.log('error:', error)
        )
      );
  }

  getProyectosWithResponse(): Observable<HttpResponse<Object>> {

    return this._httpClient.get<HttpResponse<Object>>(this._apiProyectos, { observe: 'response' }).pipe(
      tap(resp => {
        console.log('headers', resp.headers,resp.body);
        
      })
    );
  }

}
