import { FiltradorPipe } from './filtrador.pipe';

describe('FiltradorPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltradorPipe();
    expect(pipe).toBeTruthy();
  });
});
