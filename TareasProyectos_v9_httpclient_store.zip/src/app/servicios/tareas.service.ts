import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import {  HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';

import { Tarea } from '../modelos/tarea';

@Injectable()
export class TareasService {
	private _tareas:Tarea[];
	private _api="http://www.mocky.io/v2/5a2bf6862f0000281103932b";

	private _tareasObs:Observable<Tarea[]>;
	
	constructor(private _http: HttpClient){
	}

	getTareas(){
		return this._tareas;
	}

	getTareaById(tid:number):Tarea{
		return (this._tareas.filter(tarea => tarea.tid == tid)[0]);
	}

	borrarTareaById(tid: number): void {
		console.log('Borrar tid de la lista:',tid);
		for (var i = 0; i < this._tareas.length; ++i) {
			if(this._tareas[i].tid == tid ) this._tareas.splice(i,1);
		}
	}

	borrarTareaByPid(pid){
		if(this._tareas) this._tareas=this._tareas.filter(item=>{return item.proyecto!=pid?true:false;})
	}

	getTareasFromApi(){
		if(this._tareas){
			return Observable.of(this._tareas);
		}else if(this._tareasObs){
			return this._tareasObs;
		}else{
			this._tareasObs= this._http.get<Tarea[]>(this._api)
			.map((tareasfromapi: Tarea[]) => {
				this._tareas=tareasfromapi; 
				return this._tareas;
			})
			.do((tareas: Tarea[]) => {
				console.log('getTareas...',this._tareas );
			})
			.catch(this.handleError);

			return this._tareasObs;
		}

	}

	private handleError(error: Response) {
		console.error(error);
		return Observable.throw(error.json() || 'Server error');
	}

	addTarea(newTarea:Tarea){
		newTarea.tid=new Date().getTime();
		return this._http.post<any>(this._api,newTarea)
			.map((tareasfromapi: any) => {
				this._tareas.push(newTarea);
				return true;
			})
			.do((isOK: any) => {
				console.log('getTareas...',this._tareas );
			})
			.catch(this.handleError);
	}

}
