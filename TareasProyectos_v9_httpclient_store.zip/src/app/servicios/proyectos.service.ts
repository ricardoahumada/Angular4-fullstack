import { Injectable } from '@angular/core';
import {  HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import {BehaviorSubject} from 'rxjs/BehaviorSubject'

import { Proyecto } from '../modelos/proyecto';
import { TareasService } from './tareas.service';

@Injectable()
export class ProyectosService {
	private _proyectos:Proyecto[];
	private _api="http://www.mocky.io/v2/5a2bf7b32f0000871103932f";

	private _projsSub=new BehaviorSubject(this._proyectos);
	private _projsObs=this._projsSub.asObservable();


	constructor(private _http: HttpClient,private _tareaService:TareasService){
	}

	getProyectos():Proyecto[]{
		return this._proyectos;
	}

	getProyectosFromApi(){
		if(!this._proyectos){
			this._http.get<Proyecto[]>(this._api)
			.map((proyectosfromapi: Proyecto[]) => {
				this._proyectos=proyectosfromapi;
				console.log(this._proyectos);
				this._projsSub.next(this._proyectos); 
				return this._proyectos;
			})
			.do((tareas: Proyecto[]) => {
				console.log('getProyectos...',this._proyectos );
			})
			.catch(this.handleError).subscribe();
		}
		return this._projsObs;
	}

	private handleError(error: Response) {
		console.error(error);
		return Observable.throw(error.json() || 'Server error');
	}

	public borrarProyecto(pid){
		this._proyectos=this._proyectos.filter(item=>{return item.pid!=pid?true:false;});
		this._projsSub.next(this._proyectos);

		this._tareaService.borrarTareaByPid(pid);
	}

	
}
