import { Component, OnInit } from '@angular/core';

import {Tarea} from '../modelos/tarea';

import { TareasService } from '../servicios/tareas.service';


@Component({
  selector: 'app-tareas',
  templateUrl: './tareas.component.html',
  styleUrls: ['./tareas.component.css']
})
export class TareasComponent implements OnInit {
  textoafiltrar='';
  tareas:Tarea[];
  _suscription:any;

  constructor(private _tareasService:TareasService) { }

  ngOnInit() {
    this._suscription=this._tareasService.getTareasFromApi().subscribe(
      (tareasfromapi:Tarea[]) => {this.tareas = tareasfromapi;}
    );
  }

  ngOnDestroy(){
    this._suscription.unsubscribe();
  }

  borrar(tid: number): void {
   this._tareasService.borrarTareaById(tid); 
  }

}
