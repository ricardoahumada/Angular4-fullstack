import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewTareaModelComponent } from './new-tarea-model.component';

describe('NewTareaModelComponent', () => {
  let component: NewTareaModelComponent;
  let fixture: ComponentFixture<NewTareaModelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewTareaModelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewTareaModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
