import { Component, OnInit } from '@angular/core';
import {
    ReactiveFormsModule,
    FormsModule,
    FormGroup,
    FormControl,
    Validators,
    FormBuilder
} from '@angular/forms';
import { TareasService } from '../servicios/tareas.service';

import {Router} from "@angular/router";

@Component({
  selector: 'app-new-tarea-model',
  templateUrl: './new-tarea-model.component.html',
  styleUrls: ['./new-tarea-model.component.css']
})
export class NewTareaModelComponent implements OnInit {

	tareaForm: FormGroup;
	descripcion: FormControl;
	tiempo: FormControl;
	proyecto: FormControl;

	constructor(private _tareasService:TareasService,private _router: Router) { }

	ngOnInit() {
		this.createFormControls();
		this.createForm();
	}

	createFormControls() {
		this.descripcion = new FormControl('', Validators.required);
		this.tiempo = new FormControl('', Validators.required);
		this.proyecto = new FormControl('', Validators.required);
	}

	createForm() {
		this.tareaForm = new FormGroup({
		  descripcion: this.descripcion,
		  tiempo: this.tiempo,
		  proyecto: this.proyecto
		});
	}

	onSubmit(form){
		console.log(form);
		
	}

}
