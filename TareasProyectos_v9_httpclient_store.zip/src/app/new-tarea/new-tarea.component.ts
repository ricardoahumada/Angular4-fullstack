import { Component, OnInit } from '@angular/core';
import { Tarea } from '../modelos/tarea';
import {NgModel} from '@angular/forms';
import { TareasService } from '../servicios/tareas.service';
import {Router} from "@angular/router";

@Component({
  selector: 'app-new-tarea',
  templateUrl: './new-tarea.component.html',
  styleUrls: ['./new-tarea.component.css']
})
export class NewTareaComponent implements OnInit {

	private _nuevaTarea:Tarea=new Tarea();


	constructor(private _tareasService:TareasService,private _router: Router) { }

	ngOnInit() {
	}

	onSubmit(form){
		console.log(form);
		if (!form.valid) {
			return;
		}else{
			this._tareasService.addTarea(this._nuevaTarea).subscribe(
				(isOk:boolean) => {
					if(isOk) this._router.navigate(['tareas']);
				}
			);
		}
	}

}
