import { Component, OnInit } from '@angular/core';

import {Tarea} from '../modelos/tarea';

@Component({
  selector: 'app-tareas',
  templateUrl: './tareas.component.html',
  styleUrls: ['./tareas.component.css']
})
export class TareasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  tareas:Tarea[]=[
  	new Tarea(1,'Crea html',23,1),
  	new Tarea(2,'Crea js',23,2),
  	new Tarea(3,'Crea TS',23,1),
  	new Tarea(4,'Llevar a producción',23,2),
  	new Tarea(5,'Crea html',23,1),
  ];

}
