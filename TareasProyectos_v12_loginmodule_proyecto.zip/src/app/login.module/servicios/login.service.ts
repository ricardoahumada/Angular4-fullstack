import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Usuario } from '../modelos/user';

@Injectable()
export class LoginService{
	private _isAuth:boolean=false;
	private _isAuthSubj=new BehaviorSubject(this._isAuth);
	private _isAuthObs= Observable.from(this._isAuthSubj);

	login(user:Usuario){
		// Conectamos con API
		this._isAuth=true;
		this._isAuthSubj.next(this._isAuth);
		return Observable.of(this._isAuth);
	}

	isAuthenticated():Observable<boolean>{
		return this._isAuthObs;
	}
}