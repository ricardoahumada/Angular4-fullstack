import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Headers,Http, Response, RequestOptions } from '@angular/http';

import { Tarea } from '../modelos/tarea';

@Injectable()
export class TareasService {
	private _tareas:Tarea[];
	private _api="http://www.mocky.io/v2/5a2bf6862f0000281103932b";
	
	constructor(private _http: Http){
	}

	getTareas(){
		return this._tareas;
	}

	getTareaById(tid:number):Tarea{
		return (this._tareas.filter(tarea => tarea.tid == tid)[0]);
	}

	borrarTareaById(tid: number): void {
		console.log('Borrar tid de la lista:',tid);
		for (var i = 0; i < this._tareas.length; ++i) {
			if(this._tareas[i].tid == tid ) this._tareas.splice(i,1);
		}
	}

	getTareasFromApi(){
		return this._http.get(this._api)
		.map((response: Response) => {
			this._tareas=<Tarea[]>response.json(); 
			return this._tareas;
		})
		.do((tareas: Tarea[]) => {
			console.log('getTareas...',this._tareas );
		})
		.catch(this.handleError);
	}

	private handleError(error: Response) {
		console.error(error);
		return Observable.throw(error.json().error || 'Server error');
	}

}
