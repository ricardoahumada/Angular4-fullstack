import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Headers,Http, Response, RequestOptions } from '@angular/http';

import { Proyecto } from '../modelos/proyecto';

@Injectable()
export class ProyectosService {
	private _proyectos:Proyecto[];

	private _api="http://www.mocky.io/v2/5a2bf7b32f0000871103932f";


	constructor(private _http: Http){
	}

	getProyectos():Proyecto[]{
		return this._proyectos;
	}

	getProyectosFromApi(){
		return this._http.get(this._api)
		.map((response: Response) => {
			this._proyectos=<Proyecto[]>response.json(); 
			return this._proyectos;
		})
		.do((tareas: Proyecto[]) => {
			console.log('getProyectos...',this._proyectos );
		})
		.catch(this.handleError);
	}

	private handleError(error: Response) {
		console.error(error);
		return Observable.throw(error.json().error || 'Server error');
	}

	
}
